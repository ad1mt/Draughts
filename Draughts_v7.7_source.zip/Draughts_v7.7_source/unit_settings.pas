unit Unit_settings;

{$mode ObjFPC}{$H+}

interface

uses
	{$IFDEF UNIX}
		cmem
,		cthreads
,	{$ENDIF}
		sysutils
,		Classes
,		Forms
,		Controls
,		Graphics
,		Dialogs
,		LCLType
,		StdCtrls
,		Buttons
,		ComCtrls
,		Spin
,		ExtCtrls
,		ActnList
,		unit_globals
,		unit_engine
,		Unit_Help
;

type

	{ TForm2 }

 TForm2 = class(TForm)
		AutoPlay: TCheckBox;
		Borders_On_Board: TCheckBox;
		View_Database: TCheckBox;
        SQNumbers: TCheckBox;
		edit_board: TCheckBox;
		Learning_Enabled: TCheckBox;
		Database_Enabled: TCheckBox;
		Side_To_Move: TRadioGroup;
		Squares_with_borders: TCheckBox;
		HelpButton: TButton;
		Continue_Button: TButton;
		Game_State: TLabel;
		Depth_Control: TSpinEdit;
		Seconds_Control: TSpinEdit;
		StaticText1: TStaticText;
		Player_State: TLabel;
		Quit_Button: TButton;
		Load_Game: TButton;
		Save_Game: TButton;
		New_Game: TButton;
		StaticText2: TStaticText;
		StaticText3: TStaticText;
		Swap_Sides: TButton;
		Label1: TLabel;
		OpenDialog1: TOpenDialog;
		SaveDialog1: TSaveDialog;
		procedure AutoPlayChange(Sender: TObject);
		procedure Borders_On_BoardChange(Sender: TObject);
		procedure Database_EnabledChange(Sender: TObject);
		procedure Depth_ControlChange(Sender: TObject);
		procedure edit_boardClick(Sender: TObject);
		procedure FormKeyPress(Sender: TObject; var Key: char);
		procedure FormShow(Sender: TObject);
		procedure HelpButtonClick(Sender: TObject);
		procedure Continue_Button_Click(Sender: TObject);
		procedure FormCreate(Sender: TObject);
		procedure Learning_EnabledChange(Sender: TObject);
		procedure Quit_Button_Click(Sender: TObject);
		procedure Load_Game_Click(Sender: TObject);
		procedure New_Game_Click(Sender: TObject);
		procedure Save_Game_Click(Sender: TObject);
		procedure Seconds_ControlChange(Sender: TObject);
		procedure Side_To_MoveClick(Sender: TObject);
        procedure SQNumbersChange(Sender: TObject);
		procedure Squares_with_bordersChange(Sender: TObject);
		procedure Swap_Sides_Click(Sender: TObject);
		procedure View_DatabaseChange(Sender: TObject);
	private

	public

	end;

var
	Settings_Form: TForm2;

implementation

{$R *.lfm}

uses	Unit_Board;


(*----------------------------------------------*)
procedure CLOSE_DATABASE;
begin
SAVEDBASE;
DBASEARCH:= FALSE;
DBLOADED:= FALSE;
end;


(*----------------------------------------------*)
procedure LOAD_DATABASE;
var
Reply, BoxStyle: Integer;
begin
LOADBASE;
if ENGINE_ERROR_STATE then
	begin
	BoxStyle := MB_ICONQUESTION + MB_YESNO;
	Reply:= Application.MessageBox('Database not found.' + sLineBreak +  'Do you want to create it?', 'Draughts', BoxStyle);
	if Reply = IDYES then
		begin
		DISPLAY_MESS:= FALSE;
		MESS_TEXT:= '';
		ENGINE_ERROR_STATE:= FALSE;
		CREATEDBASE;
		if ENGINE_ERROR_STATE then
			showmessage(MESS_TEXT)
		else
			begin
			LOADBASE;
			if ENGINE_ERROR_STATE then
				showmessage(MESS_TEXT)
			else
				DBLOADED:= TRUE;
			end;
		end;
	end;
end;

(*----------------------------------------------*)
procedure TForm2.FormCreate(Sender: TObject);
begin
end;

(*----------------------------------------------*)
procedure TForm2.Continue_Button_Click(Sender: TObject);
begin
close;
end;

(*----------------------------------------------*)
procedure TForm2.HelpButtonClick(Sender: TObject);
begin
Help_Form.ShowModal;
end;

(*----------------------------------------------*)
procedure TForm2.edit_boardClick(Sender: TObject);
begin
if (edit_board.state = cbchecked) then
	begin
	EDIT_STATUS:= EDITING_BOARD;
	GAME_STATUS:= GAME_NOT_STARTED;
	HUMAN_EDITSQ:= 0;
	HUMAN_MOVEFROM:= 0;
	unset_cursor_from_to;
	DrawBoard(Form1.PaintBox1,BOARD1);
	Settings_Form.Game_State.Caption:= 'Editing board';
    Side_To_Move.enabled:= TRUE;
	Save_Game.enabled:= FALSE;
	Load_Game.enabled:= FALSE;
	New_Game.enabled:= FALSE;
	View_Database.enabled:= FALSE;

	if	(SIDETOMOVE = BLACK) then
		Side_To_Move.ItemIndex:= 0
	else
		Side_To_Move.ItemIndex:= 1;
	end
else
	begin
	HUMAN_EDITSQ:= 0;
	EDIT_STATUS:= NOT_EDITING;
	GAME_STATUS:= GAME_IN_PROGRESS;
	INIT_MOVEHIST;
	Settings_Form.Game_State.Caption:= 'Game started';
	if (Side_To_Move.ItemIndex = 0) then
		begin
		if (OPPONENT_SIDE = BLACK) then
			MOVE_STATUS:= OPPONENT_TO_MOVE
		else
			MOVE_STATUS:= COMPUTER_TO_MOVE
		end
	else if (Side_To_Move.ItemIndex = 1) then
		begin
		if (OPPONENT_SIDE = WHITE) then
			MOVE_STATUS:= OPPONENT_TO_MOVE
		else
			MOVE_STATUS:= COMPUTER_TO_MOVE
		end;
    Side_To_Move.enabled:= FALSE;
	Save_Game.enabled:= TRUE;
	Load_Game.enabled:= TRUE;
	New_Game.enabled:= TRUE;
	View_Database.enabled:= TRUE;
	unset_cursor_from_to;
	HUMAN_EDITSQ:= 0;
	DrawBoard(Form1.PaintBox1,BOARD1);
	end;
end;

(*----------------------------------------------*)
procedure TForm2.View_DatabaseChange(Sender: TObject);
begin
if	(View_Database.state = cbchecked) then
	begin
	if not DBLOADED then
		begin
		showmessage('You must enable the database first');
		View_Database.state:= cbUnchecked;
		end
	else
		begin
		EMPTYBOARD(BOARD3);
		EDIT_STATUS:= VIEW_DB;
		Save_Game.enabled:= FALSE;
		Load_Game.enabled:= FALSE;
		New_Game.enabled:= FALSE;
		edit_board.enabled:= FALSE;
		DrawBoard(Form1.PaintBox1,BOARD3);
		end;
	end
else if	(View_Database.state = cbUnchecked) then
	begin
	EMPTYBOARD(BOARD3);
	Save_Game.enabled:= TRUE;
	Load_Game.enabled:= TRUE;
	New_Game.enabled:= TRUE;
	edit_board.enabled:= TRUE;
	EDIT_STATUS:= NOT_EDITING;
	DrawBoard(Form1.PaintBox1,BOARD1);
	end;
end;

(*----------------------------------------------*)
procedure TForm2.FormKeyPress(Sender: TObject; var Key: char);
begin
if	(ord(Key) = 27) then close;
end;

(*----------------------------------------------*)
procedure TForm2.Side_To_MoveClick(Sender: TObject);
begin
if	(Side_To_Move.ItemIndex = 0) then
	SIDETOMOVE:= BLACK
else
	SIDETOMOVE:= WHITE;
MOVEHIST[0].HSIDE:= OPPOSITE_SIDE(SIDETOMOVE);
end;

(*----------------------------------------------*)
procedure TForm2.AutoPlayChange(Sender: TObject);
begin
if (AutoPlay.state = cbchecked) then
	GAME_STATUS:= AUTOPLAY_IN_PROGRESS
else
	GAME_STATUS:= GAME_IN_PROGRESS;
end;

(*----------------------------------------------*)
procedure TForm2.Learning_EnabledChange(Sender: TObject);
begin
if	(Learning_Enabled.state = cbchecked) then
	begin
	if not DBLOADED then
		begin
		showmessage('You must enable the database first');
		Learning_Enabled.state:= cbUnchecked;
		end
	else AUTOLEARN:= TRUE;
	end;
end;

(*----------------------------------------------*)
procedure TForm2.Database_EnabledChange(Sender: TObject);
begin
if	(Database_Enabled.state = cbchecked) then
	begin
	if not DBLOADED then
		begin
		OpenDialog1.FileName:= POSDBASEN;
		if OpenDialog1.Execute then
			if (OpenDialog1.FileName <> '') then
				begin
				POSDBASEN:= OpenDialog1.FileName;
				LOAD_DATABASE;
				end;

		if	(not DBLOADED)
		or	(ENGINE_ERROR_STATE)
		then
			begin
			Database_Enabled.state:= cbUnchecked;
			if DISPLAY_MESS then
				begin
				showmessage(MESS_TEXT);
				DISPLAY_MESS:= FALSE;
				end;
            end;
		end
	else
		showmessage('Internal error - DB already loaded!');
	end
else if	(Database_Enabled.state = cbUnchecked) then
	begin
	if DBLOADED then
		CLOSE_DATABASE;
	Learning_Enabled.state:= cbUnchecked;
	if (EDIT_STATUS = VIEW_DB) then
		begin
		EMPTYBOARD(BOARD3);
		Save_Game.enabled:= TRUE;
		Load_Game.enabled:= TRUE;
		New_Game.enabled:= TRUE;
		edit_board.enabled:= TRUE;
		View_Database.state:= cbUnchecked;
		EDIT_STATUS:= NOT_EDITING;
		end;
	DrawBoard(Form1.PaintBox1,BOARD1);
	end;
end;

(*----------------------------------------------*)
procedure TForm2.Seconds_ControlChange(Sender: TObject);
begin
if (Settings_Form.Seconds_Control.Value = 0) then exit;
TIMELIMIT:= Settings_Form.Seconds_Control.Value;
Settings_Form.Depth_Control.Value:= 0;
MAXLEVEL:= MAXINT;
end;

(*----------------------------------------------*)
procedure TForm2.Borders_On_BoardChange(Sender: TObject);
begin
if (Borders_On_Board.state = cbUnchecked) then
	Board_Margin_Size:= 0
else if (Borders_On_Board.state = cbChecked) then
	Board_Margin_Size:= 3;

border_setting_changed:= TRUE;
calc_resize(Form1);
if (EDIT_STATUS = VIEW_DB) then
	DrawBoard(Form1.PaintBox1,BOARD3)
else
	DrawBoard(Form1.PaintBox1,BOARD1);
end;

(*----------------------------------------------*)
procedure TForm2.Squares_with_bordersChange(Sender: TObject);
begin
if (Squares_with_borders.state = cbUnchecked) then Squares_have_Border:= FALSE
else if (Squares_with_borders.state = cbChecked) then Squares_have_Border:= TRUE;

border_setting_changed:= TRUE;
if (EDIT_STATUS = VIEW_DB) then
	DrawBoard(Form1.PaintBox1,BOARD3)
else
	DrawBoard(Form1.PaintBox1,BOARD1);
end;

(*----------------------------------------------*)
procedure TForm2.SQNumbersChange(Sender: TObject);
begin
if (SQNumbers.checked) then
	Squares_have_Numbers:= TRUE
else
	Squares_have_Numbers:= FALSE;
if (EDIT_STATUS = VIEW_DB) then
	DrawBoard(Form1.PaintBox1,BOARD3)
else
	DrawBoard(Form1.PaintBox1,BOARD1);
end;

(*----------------------------------------------*)
procedure TForm2.Depth_ControlChange(Sender: TObject);
var
I	:integer;
begin
if (Settings_Form.Depth_Control.Value = 0) then exit;
I:= ((Settings_Form.Depth_Control.Value - 1) * 2);
MAXLEVEL:= (3 + I);
Settings_Form.Seconds_Control.Value:= 0;
TIMELIMIT:= MAXINT;
end;

(*----------------------------------------------*)
procedure TForm2.FormShow(Sender: TObject);
begin
if	(GAME_STATUS = GAME_IN_PROGRESS) then
	Settings_Form.Game_State.Caption:= 'Game started'
else if	(GAME_STATUS = GAME_EDIT) then
	Settings_Form.Game_State.Caption:= 'Editing board'
else if	(GAME_STATUS = AUTOPLAY_IN_PROGRESS) then
	Settings_Form.Game_State.Caption:= 'Auto Playing'
else
	Settings_Form.Game_State.Caption:= 'Game not started';

if (OPPONENT_SIDE=BLACK) then
	Settings_Form.Player_State.Caption:= 'You are playing black'
else
	Settings_Form.Player_State.Caption:= 'You are playing white';

if (SIDETOMOVE = BLACK) then
	Side_To_Move.ItemIndex:= 0
else
	Side_To_Move.ItemIndex:= 1;

end;

(*----------------------------------------------*)
procedure TForm2.Quit_Button_Click(Sender: TObject);
begin
SAVEDBASE;
if ENGINE_ERROR_STATE then
	begin
	showmessage(MESS_TEXT);
	DISPLAY_MESS:= FALSE;
	MESS_TEXT:= '';
	ENGINE_ERROR_STATE:= FALSE;
	end;
write_logfile;
halt;
end;

(*----------------------------------------------*)
procedure TForm2.New_Game_Click(Sender: TObject);
begin
NEWGAME;
Side_To_Move.ItemIndex:= 0;
if (OPPONENT_SIDE=BLACK) then
	Settings_Form.Player_State.Caption:= 'You are playing black'
else
	Settings_Form.Player_State.Caption:= 'You are playing white';
Settings_Form.Game_State.Caption:= 'Game started';
cursor_X:= 0; cursor_Y:= 7;

DrawBoard(Form1.PaintBox1,BOARD1);
end;

(*----------------------------------------------*)
procedure TForm2.Swap_Sides_Click(Sender: TObject);
begin
SWAPSIDES;
if (OPPONENT_SIDE = SIDETOMOVE) then list_human_moves;

if (OPPONENT_SIDE=BLACK) then
	Settings_Form.Player_State.Caption:= 'You are playing black'
else
	Settings_Form.Player_State.Caption:= 'You are playing white';

DrawBoard(Form1.PaintBox1,BOARD1);
end;

(*----------------------------------------------*)
procedure TForm2.Load_Game_Click(Sender: TObject);
begin
if not OpenDialog1.Execute then exit;
DRLOADPOS_NAME:= OpenDialog1.FileName;
if (DRLOADPOS_NAME = '') then exit;
LOADGAMEFILE;
if DISPLAY_MESS then
	begin
	showmessage(MESS_TEXT);
	DISPLAY_MESS:= FALSE;
	exit;
	end;

Settings_Form.Game_State.Caption:= 'Game started';
if (OPPONENT_SIDE=BLACK) then
	Settings_Form.Player_State.Caption:= 'You are playing black'
else
	Settings_Form.Player_State.Caption:= 'You are playing white';

IF SIDETOMOVE=BLACK then
	// showmessage('Side to move is Black')
	Side_To_Move.ItemIndex:= 0
else
	// showmessage('Side to move is White');
	Side_To_Move.ItemIndex:= 1;

DrawBoard(Form1.PaintBox1,BOARD1);
end;

(*----------------------------------------------*)
procedure TForm2.Save_Game_Click(Sender: TObject);
begin
if not SaveDialog1.Execute then exit;
DRSAVPOS_NAME:= SaveDialog1.FileName;
if (DRSAVPOS_NAME = '') then exit;

SAVEGAMEFILE;

if DISPLAY_MESS then
	begin
	showmessage(MESS_TEXT);
	DISPLAY_MESS:= FALSE;
	end;
end;

(*----------------------------------------------*)
end.

