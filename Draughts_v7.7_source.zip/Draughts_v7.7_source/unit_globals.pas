unit unit_globals;

interface

const
	LOG_SIZE			= 333;
	DRAUGHTS_VERSION	= 'Draughts v7.7';
	LOGFILENAME			= 'LOGFILE.TXT';
	COMPUTER_MOVE_PAUSE	= 333;
	BOARDSTART			= 1;
	BOARDEND			= 35;
	ENGINE_ERROR		= TRUE;
	ENGINE_DEBUG		= TRUE;
	MAXMOVE				= 48;

type

(* These are integer types redefined for the current implemtation *)
	int8u		= byte;
	int8		= shortint;
	int16		= integer;
	int16u		= word;
	int32		= longint;
	int32u		= cardinal;
	INT64U		= QWORD;
	int			= int32;
	intu		= qword;

COLOUR			= (BLACK,WHITE,NOCOLOUR);
T_GAME_STATUS 	= (GAME_NOT_STARTED, GAME_IN_PROGRESS, AUTOPLAY_IN_PROGRESS, GAME_ENDED, GAME_EDIT);
T_MOVE_STATUS 	= (COMPUTER_TO_MOVE, OPPONENT_TO_MOVE, ANOTHERMOVE, MUSTCAPTURE, INVALIDMOVE, HUMANMOVED);
T_EDIT_STATUS	= (NOT_EDITING,EDITING_BOARD,VIEW_DB);
T_ENGINE_STATE	= (ENGINE_NOT_RUNNING, ENGINE_RUNNING,  ENGINE_AUTOPLAYING, AUTOPLAY_ENDED, ENGINE_QUIT, ENGINE_FINISHED);
P_ENGINE_STATE	= ^T_ENGINE_STATE;
T_MESS_STATUS	= (INFO_MESS,DEBUG_MESS,ERROR_MESS);

MOVESQ			= (MOVEFROM,MOVETO);
DRMOVE			= ARRAY [ MOVESQ ] OF int;
MOVETABLE		= ARRAY [0..MAXMOVE] OF DRMOVE;

BOARD_NUM_TO_XY_REC =
	RECORD
	X,Y			:int32;
	END;

var
LOG_TEXT			:array[1..LOG_SIZE] of string;
LOGI,LOGE			:integer;
LOGFILE				:TEXT;
CREATE_LOGFILE		:boolean = TRUE;

cursor_X			:integer;
cursor_Y			:integer;
cursor_from_X		:integer;
cursor_from_Y		:integer;
cursor_to_X			:integer;
cursor_to_Y			:integer;

HUMAN_MOVES			:MOVETABLE;
HUMAN_MTABEND		:integer;
HUMAN_CAPTURES		:boolean;
HUMAN_CAPTMAN		:integer;
HUMAN_MOBILITY		:integer;
HUMAN_MOVEFROM		:integer;
HUMAN_MOVETO		:integer;
HUMAN_EDITSQ		:integer;

THREAD_COUNT		:integer;
TIMER_DURATION		:integer;

GAME_STATUS			:T_GAME_STATUS;
// SIDE_LOST			:COLOUR;
MOVE_STATUS			:T_MOVE_STATUS;
EDIT_STATUS			:T_EDIT_STATUS;
ENGINE_STATE		:T_ENGINE_STATE;

DISPLAY_MESS		:boolean;
MESS_TEXT			:string;
ENGINE_ERROR_STATE	:boolean;
ENGINE_DEBUG_MODE	:boolean;
ENGINE_INFO_MODE	:boolean;

DISPLAY_BOARD		:boolean = FALSE;
Squares_have_Border	:boolean = FALSE;
Board_Has_Border	:boolean = TRUE;
border_setting_changed	:boolean = FALSE;
Squares_have_Numbers	:boolean = FALSE;

Board_Margin_Size 	:integer = 3;

BOARD_NUM_TO_XY_TAB_BLACK_AT_BOTTOM	:ARRAY [BOARDSTART..BOARDEND] of BOARD_NUM_TO_XY_REC;
BOARD_NUM_TO_XY_TAB_WHITE_AT_BOTTOM	:ARRAY [BOARDSTART..BOARDEND] of BOARD_NUM_TO_XY_REC;
BOARD_XY_TO_NUM_TAB_BLACK_AT_BOTTOM	:ARRAY [0..7,0..7] of integer;
BOARD_XY_TO_NUM_TAB_WHITE_AT_BOTTOM	:ARRAY [0..7,0..7] of integer;

procedure write_log(S:string);
procedure write_logfile;
procedure unset_cursor_from_to;
procedure quit_program;

implementation

(*----------------------------------------------*)
procedure write_log(S:string);
begin
if (LOGI < LOG_SIZE) then
	begin
	Inc(LOGI);
	LOG_TEXT[LOGI]:= S;
	LOGE:= LOGI;
	end;
end;


(*----------------------------------------------*)
procedure write_logfile;
begin
if	(LOGE > 0) then
	begin
	system.assign(LOGFILE,LOGFILENAME);
	rewrite(LOGFILE);
	for LOGI:= 1 to LOGE do
		writeln(LOGFILE,LOG_TEXT[LOGI]);
	system.close(LOGFILE);
	end;
end;


(*----------------------------------------------*)
procedure unset_cursor_from_to;
begin
cursor_from_X:= -1;
cursor_from_Y:= -1;
cursor_to_X:= -1;
cursor_to_Y:= -1;
end;


(*----------------------------------------------*)
procedure quit_program;
begin
write_logfile;
halt;
end;


(*----------------------------------------------*)
FUNCTION VALIDSQ(S:int):BOOLEAN;
BEGIN
VALIDSQ:=FALSE;
IF S >= BOARDSTART THEN
IF S <= BOARDEND THEN
IF S <> 9 THEN
IF S <> 18 THEN
IF S <> 27 THEN
  VALIDSQ:=TRUE;
END;


(*----------------------------------------------*)
procedure initiate_BOARD_XY_TO_NUM_TABS;
var S,X,XE,Y			:integer;

begin
for X:= 0 to 7 do
	for Y:= 0 to 7 do
		BOARD_XY_TO_NUM_TAB_BLACK_AT_BOTTOM[X,Y]:= 0;

X:= 1;
XE:= (X + 8);
Y:= 0;
FOR S:= BOARDSTART TO BOARDEND DO
	BEGIN
	IF VALIDSQ(S) THEN
		BEGIN
		BOARD_NUM_TO_XY_TAB_BLACK_AT_BOTTOM[S].X:= X;
		BOARD_NUM_TO_XY_TAB_BLACK_AT_BOTTOM[S].Y:= Y;

		BOARD_XY_TO_NUM_TAB_BLACK_AT_BOTTOM[X,Y]:= S;

		X:= (X + 2);
		IF (X = XE) THEN
			BEGIN
			INC(Y);
			if ((Y mod 2) = 1) then X:= 0 else X:= 1;
			XE:= (X + 8);
			END;
		END
	ELSE
		BEGIN
		BOARD_NUM_TO_XY_TAB_BLACK_AT_BOTTOM[S].X:= -1;
		BOARD_NUM_TO_XY_TAB_BLACK_AT_BOTTOM[S].Y:= -1;
		END;
	END;

for X:= 0 to 7 do
	for Y:= 0 to 7 do
		BOARD_XY_TO_NUM_TAB_WHITE_AT_BOTTOM[X,Y]:= 0;

X:= 1;
XE:= (X + 8);
Y:= 0;
FOR S:= BOARDEND DOWNTO BOARDSTART DO
	BEGIN
	IF VALIDSQ(S) THEN
		BEGIN
		BOARD_NUM_TO_XY_TAB_WHITE_AT_BOTTOM[S].X:= X;
		BOARD_NUM_TO_XY_TAB_WHITE_AT_BOTTOM[S].Y:= Y;

		BOARD_XY_TO_NUM_TAB_WHITE_AT_BOTTOM[X,Y]:= S;

		X:= (X + 2);
		IF (X = XE) THEN
			BEGIN
			INC(Y);
			if ((Y mod 2) = 1) then X:= 0 else X:= 1;
			XE:= (X + 8);
			END;
		END
	ELSE
		BEGIN
		BOARD_NUM_TO_XY_TAB_WHITE_AT_BOTTOM[S].X:= -1;
		BOARD_NUM_TO_XY_TAB_WHITE_AT_BOTTOM[S].Y:= -1;
		END;
	END;
end;

(*----------------------------------------------*)
begin

LOGI:= 0;
LOGE:= 0;
unset_cursor_from_to;
Squares_have_Border:= FALSE;
initiate_BOARD_XY_TO_NUM_TABS;
THREAD_COUNT:= 0;
TIMER_DURATION:= 250;
ENGINE_INFO_MODE:= FALSE;
DISPLAY_BOARD:= FALSE;
ENGINE_DEBUG_MODE:= TRUE;
end.

