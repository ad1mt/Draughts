unit Unit_Help;

{$mode ObjFPC}{$H+}

interface

uses
	{$IFDEF UNIX}
		cmem
,		cthreads
,	{$ENDIF}
		SysUtils
,		Classes
,		Forms
,		Controls
,		Graphics
,		Dialogs
,		StdCtrls
,		unit_globals
;

type

	{ THelp_Form }

	THelp_Form = class(TForm)
		OkButton: TButton;
		Label1: TLabel;
		Label2: TLabel;
		procedure FormCreate(Sender: TObject);
		procedure FormShow(Sender: TObject);
		procedure OkButtonClick(Sender: TObject);
		private
		public
	end;

var
	Help_Form: THelp_Form;

implementation

{$R *.lfm}

{ THelp_Form }

procedure THelp_Form.FormCreate(Sender: TObject);
begin
end;

procedure THelp_Form.FormShow(Sender: TObject);
var
help_str	:string;
begin
if (EDIT_STATUS = EDITING_BOARD) then
	help_str:=		'Use mouse click to select a square.'
	+ LineEnding +	'Upper-case [B] - insert black king.'
	+ LineEnding +	'Lower-case [b] - insert black man.'
	+ LineEnding +	'Upper-case [W] - insert white king.'
	+ LineEnding +	'Lower-case [w] - insert white man.'
	+ LineEnding +	'Space - empty square.'
	+ LineEnding +	'[ESC] key -  Go to settings.'
	+ LineEnding
else if (EDIT_STATUS = VIEW_DB) then
	help_str:=		'[Left] key - Go back one position.'
	+ LineEnding +	'[Right] key - Go forward one position.'
	+ LineEnding +	'[ALT]+[Left] key - Go back to start of database.'
	+ LineEnding +	'[ALT]+[Right] key - Go forward to end of database.'
	+ LineEnding +	'[ESC] key -  Go to settings.'
	+ LineEnding
else
	help_str:=		'Use mouse click to select and move piece.'
	+ LineEnding +	'[CTRL]+[Left] key - Go back one move.'
	+ LineEnding +	'[CTRL]+[Right] key - Go forward one move.'
	+ LineEnding +	'[ALT]+[Left] key - Go back to start of game.'
	+ LineEnding +	'[ALT]+[Right] key - Go forward to end of game.'
	+ LineEnding +	'[ESC] key -  Go to settings.'
	+ LineEnding
	;

Help_Form.Label2.Caption:= help_str;
end;

procedure THelp_Form.OkButtonClick(Sender: TObject);
begin
Self.Close
end;

end.

