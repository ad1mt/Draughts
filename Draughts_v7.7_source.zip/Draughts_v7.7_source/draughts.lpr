program Draughts;

{$mode objfpc}{$H+}

uses
	{$IFDEF UNIX}
		cmem
,		cthreads
,	{$ENDIF}
		sysutils
		{$IFDEF HASAMIGA}
,		athreads
		{$ENDIF}
,		Interfaces
,		Forms
,		Unit_Board
,		unit_engine
,		unit_globals
,		Unit_settings
,		Unit_Help;

{$R *.res}

begin
	RequireDerivedFormResource:=True;
    Application.Scaled:=True;
	Application.Initialize;
	Application.CreateForm(TForm1, Form1);
	Application.CreateForm(TForm2, Settings_Form);
	Application.CreateForm(THelp_Form, Help_Form);
	Application.Run;
end.

