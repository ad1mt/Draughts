unit unit_user;

interface

USES	SYSUTILS
,		unit_engine
,		unit_globals
;

{
const
	TITLE_0_Y				= 0;
	COMPUTERSIDE_Y			= 2;
	SIDETOMOVE_Y			= 3;
	TIMELIMIT_Y				= 4;
	MAXLEVEL_Y				= 5;
	MOVENUM_Y				= 6;

	BASE_Y					= 8;

	CMD_START_Y				= BASE_Y+0;
	CMD_END_Y				= BASE_Y+3;

	MESS_START_Y			= BASE_Y+4;
	MESS_END_Y				= BASE_Y+33;
	MESS_BEST_MOVE_Y		= BASE_Y+4;
	MESS_BEST_VAL_Y			= BASE_Y+5;
	MESS_SECS_Y				= BASE_Y+6;

	MESS_SRCH_DEPTH_Y		= BASE_Y+7;
	MESS_SRCH_MOVE_Y		= BASE_Y+8;
	MESS_SRCH_VAL_Y			= BASE_Y+9;

	DEBUG_Y					= BASE_Y+34;
	DEBUG_END_Y				= BASE_Y+41;
//	DEBUG_END_Y				= 53;

	HELP_X					= 91;
	HELP_Y					= 1;

type

	PIECHARRAY			=ARRAY [1..5] OF STRING[8];

var
I					:int32;
DB_VAL				:INT32;
BOARD1_DISPLAYED,
COMMANDLINE,
SQUNUM				:BOOLEAN;
HCMD,
HUMANCMDSTR			:string;

PROCEDURE unit_initialise;
}

implementation

{
const
	BOARDXOFF					= 22;

var
	I32						:int32;

	CAPTURES			:BOOLEAN;

	WMCHAR				:PIECHARRAY;
	WKCHAR				:PIECHARRAY;
	BMCHAR				:PIECHARRAY;
	BKCHAR				:PIECHARRAY;
	DKCHAR				:PIECHARRAY;
	EMCHAR				:PIECHARRAY;

	SQU32ITAB			:ARRAY [1..35] OF int32;
	SQU35ITAB			:ARRAY [1..32] OF int32;

	SQ2POS				:ARRAY [BOARDSTART..BOARDEND] OF
									RECORD X,Y	:int32 END;

	TOPHBDR,
	BOTHBDR				:string;
}


(******************)
PROCEDURE unit_initialise;
var
I,S,X,Y			:int32;

BEGIN
{
I:=32;
FOR S:=BOARDSTART TO BOARDEND DO
  BEGIN
  IF VALIDSQ(S) THEN
    BEGIN
    SQU32ITAB[S]:=I;
    SQU35ITAB[I]:=S;
    I:=I-1;
    END
  ELSE
    SQU32ITAB[S]:= NULLPIECE;
  END;

BOARD1_DISPLAYED:=TRUE;
}
END;


(******************)
initialization
begin
unit_initialise;
end;

end.

