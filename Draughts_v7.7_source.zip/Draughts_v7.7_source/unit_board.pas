unit Unit_Board;
{$mode ObjFPC}{$H+}

interface

uses
	{$IFDEF UNIX}
		cmem
,		cthreads
,	{$ENDIF}
		SysUtils
,		Classes
,		Forms
,		Controls
,		Graphics
,		StdCtrls
,		ExtCtrls
,		Dialogs
,		LCLType
,		XMLPropStorage
,		unit_engine
,		unit_globals
,		unit_settings
;

{$include Int_Common_Types.inc}

type

{ TForm1 }

TForm1 = class(TForm)
        IdleTimer1: TIdleTimer;
	PaintBox1: TPaintBox;
	Timer1: TTimer;
	XMLPropStorage1: TXMLPropStorage;
	procedure FormClose(Sender: TObject {; var CloseAction: TCloseAction});
	procedure FormCreate(Sender: TObject);
	procedure FormKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
	procedure FormKeyPress(Sender: TObject; var Key: char);
	procedure FormPaint(Sender: TObject);
	procedure FormResize(Sender: TObject);
    procedure IdleTimer1StartTimer(Sender: TObject);
    procedure IdleTimer1StopTimer(Sender: TObject);
    procedure IdleTimer1Timer(Sender: TObject);
    procedure PaintBox1Click(Sender: TObject);
	procedure PaintBox1MouseUp(Sender: TObject; Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
	procedure PaintBox1Paint(Sender: TObject);
	procedure Timer1Timer(Sender: TObject);
	private
	public
	end;

var
Form1					:TForm1;
resizing_form			:boolean = false;

procedure DrawBoard(PaintBox1:TPaintBox; P_BOARD:T_BOARD);
procedure calc_resize(Form1:TForm1);

implementation
{$R *.lfm}

const
	White_Man_File	= 'White_Man.bmp';
	White_King_File	= 'White_King.bmp';
	Black_Man_File	= 'Black_Man.bmp';
	Black_King_File	= 'Black_King.bmp';

type

T_SQ_HILITE = (NOHILITE, HILITED, SELECTED, REDLITED, BLUELITED);
T_PIECE		= (NOPIECE, BLACK_MAN, BLACK_KING, WHITE_MAN, WHITE_KING);

Board_Pixel_XY_Record =
	record
	left_X	:integer;
	right_X	:integer;
	top_Y	:integer;
	bot_Y	:integer;
	end;

var
X	:integer;

White_Man_bitmap,
White_King_bitmap,
Black_Man_bitmap,
Black_King_bitmap	:TBitmap;

Prev_Form_W	:integer = 0;
Prev_Form_H	:integer = 0;
SquareSize  :integer;

PIECE_IMAGES_LOADED		:boolean;
Processing_Timer_Message	:boolean;

LITEGRAY,
LITEBLACK,
DARKYELLOW,
LITEGREEN,
DARKBLUE,
DARKRED		:Tcolor;

From_Piece	:T_PIECE;
To_Piece	:T_PIECE;

Board_Pixel_XY_Table	:array[0..7,0..7] of Board_Pixel_XY_Record;

THRID	:TThreadID;

procedure draw_square_and_piece_XY(PaintBox1:TPaintBox; X,Y:Integer; HILITE:T_SQ_HILITE=NOHILITE); forward;
procedure draw_square_and_piece_SQNUM(PaintBox1:TPaintBox; PIECE:T_PIECE; S:Integer; HILITE:T_SQ_HILITE=NOHILITE); forward;

(*----------------------------------------------*)
procedure Initiate_Board_Pixel_XY_Table;
var
X,Y,
SSX,SSY,
SX,SY	:Integer;

begin
for Y:= 0 to 7 do
	begin
	SY:= (Y * SquareSize);
	SSY:= (SY + SquareSize);
	for X:= 0 to 7 do
		begin
		SX:= (X * SquareSize);
		SSX:= (SX + SquareSize);
		Board_Pixel_XY_Table[X,Y].left_X:= SX;
		Board_Pixel_XY_Table[X,Y].right_X:= SSX;
		Board_Pixel_XY_Table[X,Y].top_Y:= SY;
		Board_Pixel_XY_Table[X,Y].bot_Y:= SSY;
		end;
	end;
end;


(*----------------------------------------------*)
procedure DrawSquare1(PaintBox1:TPaintBox; X,Y:Integer; hilite:T_SQ_HILITE=NOHILITE; SQ:Integer=0);
var
S32,
HILITE_SIZE,
SSX,SSY,
SX,SY,
TX,TY,
TSX,TSY	:Integer;
SQNUM	:string;

	function select_gray_colour:TColor;
	begin
	if (hilite = NOHILITE) then result:= LITEGRAY;
	if (hilite = HILITED) then result:= DARKYELLOW;
	if (hilite = REDLITED) then result:= DARKRED;
	if	(hilite = BLUELITED) then result:= DARKBLUE;
	if (hilite = SELECTED) then result:= LITEGREEN;
	end;

	function select_black_colour:TColor;
	begin
	if (hilite = NOHILITE) then result:= LITEBLACK;
	if (hilite = HILITED) then result:= DARKYELLOW;
	if (hilite = REDLITED) then result:= DARKRED;
	if (hilite = BLUELITED) then result:= DARKBLUE;
	if (hilite = SELECTED) then result:= LITEGREEN;
	end;

	procedure paint_black_square;
	begin
	SX:= (X * SquareSize);
	SSX:= (SX + SquareSize);
	PaintBox1.Canvas.Rectangle(SX, SY, SSX, SSY);

	if (hilite <> NOHILITE) then
		begin
		TX:= (SX + HILITE_SIZE);
		TSX:= (SSX - HILITE_SIZE);
		PaintBox1.Canvas.Pen.Color := LITEBLACK;
		PaintBox1.Canvas.Brush.Color:= LITEBLACK;
		PaintBox1.Canvas.Rectangle(TX, TY, TSX, TSY);
		end;
	end;

	procedure paint_white_square;
	begin
	SX:= (X * SquareSize);
	SSX:= (SX + SquareSize);
	PaintBox1.Canvas.Rectangle(SX, SY, SSX, SSY);

	if (hilite <> NOHILITE) then
		begin
		TX:= (SX + HILITE_SIZE);
		TSX:= (SSX - HILITE_SIZE);
		PaintBox1.Canvas.Pen.Color := LITEGRAY;
		PaintBox1.Canvas.Brush.Color:= LITEGRAY;
		PaintBox1.Canvas.Rectangle(TX, TY, TSX, TSY);
		end;
	end;

begin
HILITE_SIZE:= (SquareSize div 12);
if (HILITE_SIZE < 8) then HILITE_SIZE:= 8;

SY:= (Y * SquareSize);
SSY:= (SY + SquareSize);
TY:= SY + HILITE_SIZE;
TSY:= SSY - HILITE_SIZE;

if odd(Y) then
	begin
	if odd(X) then
		begin
		PaintBox1.Canvas.Brush.Color := select_black_colour;
		if	Squares_have_Border then
			PaintBox1.Canvas.Pen.Color := clLtGray
		else
			PaintBox1.Canvas.Pen.Color := select_black_colour;
		paint_black_square;
		end
	else
		begin
		PaintBox1.Canvas.Brush.Color := select_gray_colour;
		if	Squares_have_Border then
			PaintBox1.Canvas.Pen.Color := clLtGray
		else
			PaintBox1.Canvas.Pen.Color := select_gray_colour;
		paint_white_square;
		if Squares_have_Numbers then
			if ENGINE_DEBUG_MODE then
				begin
				if	(SQ <> 0) then
					SQNUM:= inttostr(SQ)
				else
					SQNUM:= '';
			    PaintBox1.Canvas.Font.Color:=RGBToColor(255,255,255);
		        PaintBox1.Canvas.Brush.Style:=bsClear;
		        PaintBox1.Canvas.TextOut(SX,SY,SQNUM);
				end
			else
				begin
				if	(SQ <> 0) then
					begin
					S32:= SQU32ITAB[SQ];
					SQNUM:= inttostr(S32);
					end
				else
					SQNUM:= '';
			    PaintBox1.Canvas.Font.Color:=RGBToColor(255,255,255);
		        PaintBox1.Canvas.Brush.Style:=bsClear;
		        PaintBox1.Canvas.TextOut(SX,SY,SQNUM);
				end;
		end;
	end
else
	begin
	if odd(X) then
		begin
		PaintBox1.Canvas.Brush.Color := select_gray_colour;
		if	Squares_have_Border then
			PaintBox1.Canvas.Pen.Color := clLtGray
		else
			PaintBox1.Canvas.Pen.Color := select_gray_colour;
		paint_white_square;
		if Squares_have_Numbers then
			if ENGINE_DEBUG_MODE then
				begin
				if	(SQ <> 0) then
					SQNUM:= inttostr(SQ)
				else
					SQNUM:= '';
			    PaintBox1.Canvas.Font.Color:=RGBToColor(255,255,255);
		        PaintBox1.Canvas.Brush.Style:=bsClear;
		        PaintBox1.Canvas.TextOut(SX,SY,SQNUM);
				end
			else
				begin
				if	(SQ <> 0) then
					begin
					S32:= SQU32ITAB[SQ];
					SQNUM:= inttostr(S32);
					end
				else
					SQNUM:= '';
			    PaintBox1.Canvas.Font.Color:=RGBToColor(255,255,255);
		        PaintBox1.Canvas.Brush.Style:=bsClear;
		        PaintBox1.Canvas.TextOut(SX,SY,SQNUM);
				end;
		end
	else
		begin
		PaintBox1.Canvas.Brush.Color := select_black_colour;
		if	Squares_have_Border then
			PaintBox1.Canvas.Pen.Color := clLtGray
		else
			PaintBox1.Canvas.Pen.Color := select_black_colour;
		paint_black_square;
		end;
	end;

PaintBox1.Canvas.Pen.Color := clBlack;
end;


(*----------------------------------------------*)
procedure DrawPiece1(PaintBox1:TPaintBox; X,Y:Integer; Piece:T_PIECE; SQ:Integer=0);
var
PIECE_WIDTH,
PIECE_MARGIN,
S32,
SSX,SSY,
SX,SY,
TX,TY,
TKX,TKY,
TSX,TSY,
TKSX,TKSY	:Integer;
SQNUM	:string;
R	:TRect;

begin
if	(Piece = NOPIECE) then exit;

if (Y < 8) then
	begin
	PIECE_WIDTH:= ((SquareSize div 2) + (SquareSize div 8));
	PIECE_MARGIN:= ((SquareSize - PIECE_WIDTH) div 2);

	SY:= (Y * SquareSize);
	SSY:= (SY + SquareSize);
	TY:= (SY + (PIECE_MARGIN * 2));
	TSY:= (TY + ((PIECE_WIDTH * 2) div 3));
	TKY:= (SY + PIECE_MARGIN);
	TKSY:= (TKY + ((PIECE_WIDTH * 2) div 3));

	if (X < 8) then
		begin
		if	(Piece = WHITE_MAN) then
			begin
			SX:= (X * SquareSize);
			SSX:= (SX + SquareSize);
			TX:= (SX + PIECE_MARGIN);
			TSX:= (TX + PIECE_WIDTH);
			if not PIECE_IMAGES_LOADED then
				begin
				PaintBox1.Canvas.Pen.Color := LITEBLACK;
				PaintBox1.Canvas.Brush.Color := clwhite;
				PaintBox1.Canvas.Ellipse(TX, TY, TSX, TSY);
				end
			else
				begin
				R.Left:= TX;
				R.Top:= (SY + ((TY-SY) div 2));
				R.Right:= TSX;
				R.Bottom:= TSY;
				PaintBox1.Canvas.StretchDraw(R,White_Man_bitmap);
				end;
			end;

		if	(Piece = BLACK_MAN) then
			begin
			SX:= (X * SquareSize);
			SSX:= (SX + SquareSize);
			TX:= (SX + PIECE_MARGIN);
			TSX:= (TX + PIECE_WIDTH);
			if not PIECE_IMAGES_LOADED then
				begin
				PaintBox1.Canvas.Pen.Color := LITEGRAY;
				PaintBox1.Canvas.Brush.Color := clblack;
				PaintBox1.Canvas.Ellipse(TX, TY, TSX, TSY);
				end
			else
				begin
				R.Left:= TX;
				R.Top:= (SY + ((TY-SY) div 2));
				R.Right:= TSX;
				R.Bottom:= TSY;
				PaintBox1.Canvas.StretchDraw(R,Black_Man_bitmap);
				end;
			end;

		if	(Piece = WHITE_KING) then
			begin
			SX:= (X * SquareSize);
			SSX:= (SX + SquareSize);
			TX:= (SX + PIECE_MARGIN);
			TSX:= (TX + PIECE_WIDTH);

			if not PIECE_IMAGES_LOADED then
				begin
				PaintBox1.Canvas.Pen.Color := LITEBLACK;
				PaintBox1.Canvas.Brush.Color := clwhite;
				PaintBox1.Canvas.Ellipse(TX, TKY, TSX, TKSY);
				end
			else
				begin
				R.Left:= TX;
				R.Top:= (SY + ((TY-SY) div 2));
				R.Right:= TSX;
				R.Bottom:= TSY;
				PaintBox1.Canvas.StretchDraw(R,White_King_bitmap);
				end;
			end;

		if	(Piece = BLACK_KING) then
			begin
			SX:= (X * SquareSize);
			SSX:= (SX + SquareSize);
			TX:= (SX + PIECE_MARGIN);
			TSX:= (TX + PIECE_WIDTH);

			if not PIECE_IMAGES_LOADED then
				begin
				PaintBox1.Canvas.Pen.Color := LITEGRAY;
				PaintBox1.Canvas.Brush.Color := clblack;
				PaintBox1.Canvas.Ellipse(TX, TKY, TSX, TKSY);
				end
			else
				begin
				R.Left:= TX;
				R.Top:= (SY + ((TY-SY) div 2));
				R.Right:= TSX;
				R.Bottom:= TSY;
				PaintBox1.Canvas.StretchDraw(R,Black_King_bitmap);
				end;
			end;

		if Squares_have_Numbers then
			if ENGINE_DEBUG_MODE then
				begin
				if	(SQ <> 0) then
					SQNUM:= inttostr(SQ)
				else
					SQNUM:= '';
			    PaintBox1.Canvas.Font.Color:=RGBToColor(255,255,255);
		        PaintBox1.Canvas.Brush.Style:=bsClear;
		        PaintBox1.Canvas.TextOut(SX,SY,SQNUM);
				end
			else
				begin
				if	(SQ <> 0) then
					begin
					S32:= SQU32ITAB[SQ];
					SQNUM:= inttostr(S32);
					end
				else
					SQNUM:= '';
			    PaintBox1.Canvas.Font.Color:=RGBToColor(255,255,255);
		        PaintBox1.Canvas.Brush.Style:=bsClear;
		        PaintBox1.Canvas.TextOut(SX,SY,SQNUM);
				end;
		end;
	end;
PaintBox1.Canvas.Pen.Color := clBlack;
end;


(*----------------------------------------------*)
procedure DrawBoard(PaintBox1:TPaintBox; P_BOARD:T_BOARD);
var
S,X,Y	:Integer;
Piece		:T_PIECE;

begin
if border_setting_changed then
	begin
	PaintBox1.Canvas.Pen.Color := cldefault;
	PaintBox1.Canvas.Brush.Color:= cldefault;
	PaintBox1.Canvas.Rectangle(0, 0, PaintBox1.Width, PaintBox1.Height);
	end;

for Y:= 0 to 7 do
	for X:= 0 to 7 do
		begin
        if	(OPPONENT_SIDE = BLACK) then
	        S:= BOARD_XY_TO_NUM_TAB_BLACK_AT_BOTTOM[X,Y]
        else
	        S:= BOARD_XY_TO_NUM_TAB_WHITE_AT_BOTTOM[X,Y];
		DrawSquare1(PaintBox1,X,Y,NOHILITE,S);
		end;

if	(OPPONENT_SIDE = BLACK) then
	for S:= BOARDSTART to BOARDEND do
		begin
		if	(BOARD_NUM_TO_XY_TAB_BLACK_AT_BOTTOM[S].X > -1) then
			begin
			case P_BOARD[S] of
				EMPTY:			Piece:= NOPIECE;
				WHITEMAN_SCORE:	Piece:= WHITE_MAN;
				WHITEKING_SCORE:Piece:= WHITE_KING;
				BLACKMAN_SCORE:	Piece:= BLACK_MAN;
				BLACKING_SCORE:	Piece:= BLACK_KING;
				end;
			if	(Piece <> NOPIECE) then
				DrawPiece1( PaintBox1, BOARD_NUM_TO_XY_TAB_BLACK_AT_BOTTOM[S].X, BOARD_NUM_TO_XY_TAB_BLACK_AT_BOTTOM[S].Y, Piece, S);
			end;
		end
else
	for S:= BOARDSTART to BOARDEND do
		begin
		if	(BOARD_NUM_TO_XY_TAB_WHITE_AT_BOTTOM[S].X > -1) then
			begin
			case P_BOARD[S] of
				EMPTY:			Piece:= NOPIECE;
				WHITEMAN_SCORE:	Piece:= WHITE_MAN;
				WHITEKING_SCORE:Piece:= WHITE_KING;
				BLACKMAN_SCORE:	Piece:= BLACK_MAN;
				BLACKING_SCORE:	Piece:= BLACK_KING;
				end;
			if	(Piece <> NOPIECE) then
				DrawPiece1( PaintBox1, BOARD_NUM_TO_XY_TAB_WHITE_AT_BOTTOM[S].X, BOARD_NUM_TO_XY_TAB_WHITE_AT_BOTTOM[S].Y, Piece, S);
			end;
		end;
end;


(*----------------------------------------------*)
procedure draw_square_and_piece_XY(PaintBox1:TPaintBox; X,Y:Integer; HILITE:T_SQ_HILITE=NOHILITE);
var
S	:integer;
Piece	:T_PIECE;

begin

if	(OPPONENT_SIDE = BLACK) then
	S:= BOARD_XY_TO_NUM_TAB_BLACK_AT_BOTTOM[X,Y]
else
	S:= BOARD_XY_TO_NUM_TAB_WHITE_AT_BOTTOM[X,Y];

DrawSquare1(Form1.PaintBox1,X,Y,HILITE,S);

if	(S > 0) then
	begin
	case BOARD1[S] of
		EMPTY:
			Piece:= NOPIECE;
		WHITEMAN_SCORE:
			Piece:= WHITE_MAN;
		WHITEKING_SCORE:
			Piece:= WHITE_KING;
		BLACKMAN_SCORE:
			Piece:= BLACK_MAN;
		BLACKING_SCORE:
			Piece:= BLACK_KING;
	end;
	DrawPiece1(Form1.PaintBox1,X,Y,Piece);
	end;
end;

(*----------------------------------------------*)
procedure draw_square_and_piece_SQNUM(PaintBox1:TPaintBox; PIECE:T_PIECE; S:Integer; HILITE:T_SQ_HILITE=NOHILITE);
begin
if	(OPPONENT_SIDE = BLACK) then
	begin
	DrawSquare1(
		PaintBox1,
		BOARD_NUM_TO_XY_TAB_BLACK_AT_BOTTOM[S].X,
		BOARD_NUM_TO_XY_TAB_BLACK_AT_BOTTOM[S].Y,
		HILITE,
		S);
	DrawPiece1(
		PaintBox1,
		BOARD_NUM_TO_XY_TAB_BLACK_AT_BOTTOM[S].X,
		BOARD_NUM_TO_XY_TAB_BLACK_AT_BOTTOM[S].Y,
		PIECE );
	end
else
	begin
	DrawSquare1(
		PaintBox1,
		BOARD_NUM_TO_XY_TAB_WHITE_AT_BOTTOM[S].X,
		BOARD_NUM_TO_XY_TAB_WHITE_AT_BOTTOM[S].Y,
		HILITE,
		S);
	DrawPiece1(
		PaintBox1,
		BOARD_NUM_TO_XY_TAB_WHITE_AT_BOTTOM[S].X,
		BOARD_NUM_TO_XY_TAB_WHITE_AT_BOTTOM[S].Y,
		PIECE );
	end;
end;


(*----------------------------------------------*)
procedure load_piece_images;
begin
PIECE_IMAGES_LOADED:= TRUE;

White_Man_bitmap:= TBitmap.Create;
try	White_Man_bitmap.LoadFromFile(White_Man_File);
except PIECE_IMAGES_LOADED:= FALSE;
end;

White_King_bitmap:= TBitmap.Create;
try White_King_bitmap.LoadFromFile(White_King_File);
except PIECE_IMAGES_LOADED:= FALSE;
end;

Black_Man_bitmap:= TBitmap.Create;
try Black_Man_bitmap.LoadFromFile(Black_Man_File);
except PIECE_IMAGES_LOADED:= FALSE;
end;

Black_King_bitmap:= TBitmap.Create;
try Black_King_bitmap.LoadFromFile(Black_King_File);
except PIECE_IMAGES_LOADED:= FALSE;
end;

if (PIECE_IMAGES_LOADED = FALSE) then
	showmessage('Could not load all image files');
end;


(*---------------------v2------------------------*)
procedure calc_resize(Form1:TForm1);
var
W,H				:integer;
H_or_W_changed	:boolean;

begin
H_or_W_changed:= FALSE;
H:= Form1.Height;
W:= Form1.Width;

if ((Form1.Height <> Prev_Form_H) and (Form1.Width = Prev_Form_W)) then
	begin
	if	((H mod 8) <> 0) then
		H:= (H - (H mod 8));
	W:= H;
	H_or_W_changed:= TRUE;
	end
else if ((Form1.Height = Prev_Form_H) and (Form1.Width <> Prev_Form_W)) then
	begin
	if	((W mod 8) <> 0) then
		W:= (W - (W mod 8));
	H:= W;
	H_or_W_changed:= TRUE;
	end
else if ((Form1.Height > Prev_Form_H) and (Form1.Width < Prev_Form_W)) then
	begin
	if	((H mod 8) <> 0) then
		H:= (H - (H mod 8));
	W:= H;
	H_or_W_changed:= TRUE;
	end
else if ((Form1.Height < Prev_Form_H) and (Form1.Width > Prev_Form_W)) then
	begin
	if	((W mod 8) <> 0) then
		W:= (W - (W mod 8));
	H:= W;
	H_or_W_changed:= TRUE;
	end
else if ((Form1.Height < Prev_Form_H) and (Form1.Width < Prev_Form_W)) then
	begin
	if (H > W) then W:= H
	else if (W > H) then H:= W;

	if	((H mod 8) <> 0) then
		H:= (H - (H mod 8));
	W:= H;
	H_or_W_changed:= TRUE;
	end
else if ((Form1.Height > Prev_Form_H) and (Form1.Width > Prev_Form_W)) then
	begin
	if (H > W) then W:= H
	else if (W > H) then H:= W;

	if	((H mod 8) <> 0) then
		H:= (H - (H mod 8));
	W:= H;
	H_or_W_changed:= TRUE;
	end;

if	border_setting_changed then
	begin
	if (H > W) then W:= H
	else if (W > H) then H:= W;

	if	((H mod 8) <> 0) then
		H:= (H - (H mod 8));
	W:= H;
	H_or_W_changed:= TRUE;
	end;

if H_or_W_changed then
	begin
	SquareSize:= (W div 8);
	Prev_Form_W:= (W + (2 * Board_Margin_Size));
	Prev_Form_H:= (H + (2 * Board_Margin_Size));
	Form1.Width:= Prev_Form_W;
	Form1.Height:= Prev_Form_H;
    Form1.PaintBox1.Left:= Board_Margin_Size;
    Form1.PaintBox1.Top:= Board_Margin_Size;
	Form1.PaintBox1.Width:= W;
	Form1.PaintBox1.Height:= H;
	Initiate_Board_Pixel_XY_Table;
	end;

if ((Form1.Left + Form1.Width) < 1) then
	Form1.Left:= Form1.Left + (20 - (Form1.Left + Form1.Width));
end;


(*----------------------------------------------*)
procedure TForm1.FormCreate(Sender: TObject);
begin
Processing_Timer_Message:=FALSE;
self.Caption:= DRAUGHTS_VERSION;
if (Form1.Left < 0) then Form1.Left:= 0;
calc_resize(Self);
Form1.KeyPreview := True;
end;


(*----------------------------------------------*)
procedure TForm1.FormResize(Sender: TObject);
var	X,Y	:Integer;
begin
if not resizing_form then resizing_form:= true;
// calc_resize(Self);
end;

(*----------------------------------------------*)
procedure TForm1.IdleTimer1StartTimer(Sender: TObject);
begin
resizing_form:= false;
calc_resize(Self);
end;

(*----------------------------------------------*)
procedure TForm1.IdleTimer1StopTimer(Sender: TObject);
begin
end;

(*----------------------------------------------*)
procedure TForm1.IdleTimer1Timer(Sender: TObject);
begin
end;


(*----------------------------------------------*)
procedure TForm1.PaintBox1Click(Sender: TObject);
begin
end;


(*----------------------------------------------*)
procedure TForm1.PaintBox1Paint(Sender: TObject);
begin
if (EDIT_STATUS = VIEW_DB) then
	DrawBoard(Form1.PaintBox1,BOARD3)
else
	DrawBoard(Form1.PaintBox1,BOARD1);
end;


(*----------------------------------------------*)
procedure Process_Edit_Square(Form1:TForm1; key:char);
var
S		:integer;
Piece	:T_PIECE;
BoxStyle:Integer;

begin
if	(HUMAN_EDITSQ = 0) then
	begin
	if	(ord(Key) = 32) then
		begin
		BoxStyle := MB_ICONQUESTION + MB_YESNO;
        if Application.MessageBox('Clear all squares', 'Board Edit', BoxStyle)
		= IDYES then
        	begin
		    EMPTYBOARD(BOARD1);
		    DrawBoard(Form1.PaintBox1,BOARD1);
			end;
		end;
	end
else
	begin
	if	(ord(Key) = 32) then
		begin
		BOARD1[HUMAN_EDITSQ]:= EMPTY;
		DrawSquare1(Form1.PaintBox1, cursor_from_X, cursor_from_Y, BLUELITED, HUMAN_EDITSQ);
		end;
	if	(ord(Key) = 98) then
		begin
		BOARD1[HUMAN_EDITSQ]:= BLACKMAN_SCORE;
		DrawSquare1(Form1.PaintBox1, cursor_from_X, cursor_from_Y, BLUELITED, HUMAN_EDITSQ);
		DrawPiece1(Form1.PaintBox1, cursor_from_X, cursor_from_Y, BLACK_MAN);
		end;
	if	(ord(Key) = 66) then
		begin
		BOARD1[HUMAN_EDITSQ]:= BLACKING_SCORE;
		DrawSquare1(Form1.PaintBox1, cursor_from_X, cursor_from_Y, BLUELITED, HUMAN_EDITSQ);
		DrawPiece1(Form1.PaintBox1, cursor_from_X, cursor_from_Y, BLACK_KING);
		end;
	if	(ord(Key) = 119) then
		begin
		BOARD1[HUMAN_EDITSQ]:= WHITEMAN_SCORE;
		DrawSquare1(Form1.PaintBox1, cursor_from_X, cursor_from_Y, BLUELITED, HUMAN_EDITSQ);
		DrawPiece1(Form1.PaintBox1, cursor_from_X, cursor_from_Y, WHITE_MAN);
		end;
	if	(ord(Key) = 87) then
		begin
		BOARD1[HUMAN_EDITSQ]:= WHITEKING_SCORE;
		DrawSquare1(Form1.PaintBox1, cursor_from_X, cursor_from_Y, BLUELITED, HUMAN_EDITSQ);
		DrawPiece1(Form1.PaintBox1, cursor_from_X, cursor_from_Y, WHITE_KING);
		end;
    // showmessage('ord(key) = '+inttostr(ord(key)));
	end;
end;


(*----------------------------------------------*)
procedure Human_Edit_Selected(Form1:TForm1);
var
S		:integer;
Piece	:T_PIECE;

begin
if	(EDIT_STATUS <> EDITING_BOARD) then
	begin
	showmessage('Human_Edit_Selected() called when EDIT_STATUS <> EDITING_BOARD');
	exit;
	end;

if	(OPPONENT_SIDE = BLACK) then
	S:= BOARD_XY_TO_NUM_TAB_BLACK_AT_BOTTOM[cursor_X,cursor_Y]
else
	S:= BOARD_XY_TO_NUM_TAB_WHITE_AT_BOTTOM[cursor_X,cursor_Y];

if	(S > 0) then
	begin
	if	(HUMAN_EDITSQ = S) then
		begin
		case BOARD1[S] of
			EMPTY:			Piece:= NOPIECE;
			WHITEMAN_SCORE:	Piece:= WHITE_MAN;
			WHITEKING_SCORE:Piece:= WHITE_KING;
			BLACKMAN_SCORE:	Piece:= BLACK_MAN;
			BLACKING_SCORE:	Piece:= BLACK_KING;
			end;
		DrawSquare1(Form1.PaintBox1, cursor_from_X, cursor_from_Y, NOHILITE, S);
		DrawPiece1(Form1.PaintBox1, cursor_from_X, cursor_from_Y, Piece);
		cursor_from_X:= -1;	cursor_from_Y:= -1;
		HUMAN_EDITSQ:= 0;
		end
	else
		begin
		if	(HUMAN_EDITSQ <> 0) then
			begin
			case BOARD1[HUMAN_EDITSQ] of
				EMPTY:			Piece:= NOPIECE;
				WHITEMAN_SCORE:	Piece:= WHITE_MAN;
				WHITEKING_SCORE:Piece:= WHITE_KING;
				BLACKMAN_SCORE:	Piece:= BLACK_MAN;
				BLACKING_SCORE:	Piece:= BLACK_KING;
				end;
			DrawSquare1(Form1.PaintBox1, cursor_from_X, cursor_from_Y, NOHILITE, HUMAN_EDITSQ);
			DrawPiece1(Form1.PaintBox1, cursor_from_X, cursor_from_Y, Piece);
			cursor_from_X:= -1;	cursor_from_Y:= -1;
			HUMAN_EDITSQ:= 0;
			end;
		cursor_from_X:= cursor_X;
		cursor_from_Y:= cursor_Y;
		case BOARD1[S] of
			EMPTY:			Piece:= NOPIECE;
			WHITEMAN_SCORE:	Piece:= WHITE_MAN;
			WHITEKING_SCORE:Piece:= WHITE_KING;
			BLACKMAN_SCORE:	Piece:= BLACK_MAN;
			BLACKING_SCORE:	Piece:= BLACK_KING;
			end;
		DrawSquare1(Form1.PaintBox1, cursor_from_X, cursor_from_Y, BLUELITED, S);
		DrawPiece1(Form1.PaintBox1, cursor_from_X, cursor_from_Y, Piece);
		HUMAN_EDITSQ:= S;
		end;
	end;
end;


(*----------------------------------------------*)
procedure start_computer_move(called_from:string);
begin
cursor_X:= -1; cursor_Y:= -1;
DrawBoard(Form1.PaintBox1,BOARD1);

if	(THREAD_COUNT <> 0) then
	begin
	showmessage('start_computer_move(): THREAD_COUNT > 0 [called from '+called_from+']');
	end
else
	begin
	ENGINE_STATE:= ENGINE_RUNNING;
    THRID:= BeginThread(@COMPUTER_MOVE,pointer(@ENGINE_STATE));
    Form1.Timer1.interval:= TIMER_DURATION;
    Form1.Timer1.enabled:= TRUE;
	end
end;


(*----------------------------------------------*)
procedure continue_game(called_from:string);
begin
if	(SIDETOMOVE = COMPUTER_SIDE) then
	start_computer_move(called_from)
else
	begin
	HUMAN_MOVEFROM:= 0;
	HUMAN_MOVETO:= 0;
	From_Piece:= NoPiece;
	unset_cursor_from_to;
	cursor_X:= -1; cursor_Y:= -1;

	HUMAN_CAPTURES:= FALSE;
	HUMAN_CAPTMAN:= EMPTY;
	LISTMOVES
		(
		OPPONENT_SIDE,
		HUMAN_CAPTMAN,
		HUMAN_MOVES,
		HUMAN_CAPTURES,
		1,
		HUMAN_MTABEND,
		HUMAN_MOBILITY
		);
	IF (HUMAN_MTABEND = 1) AND NOT HUMAN_CAPTURES THEN
		BEGIN
		GAME_STATUS:= GAME_ENDED;
		showmessage('You have lost!');
		exit
		END;
	end;
end;


(*----------------------------------------------*)
procedure display_computer_move(PaintBox1:TPaintBox);
var
P,PP,MI,S	:integer;
C			:COLOUR;
Piece,PPiece:T_PIECE;

begin
if	(GAME_STATUS = GAME_ENDED)
or	(MOVEINDEX = 0)
then
	begin
	DISPLAY_MESS:= TRUE;
	MESS_TEXT:= 'Computer did not complete a move - game ended';
	GAME_STATUS:= GAME_ENDED;
	exit;
	end;
MI:= MOVEINDEX;
C:= MOVEHIST[MI].HSIDE;
P:= BOARD1[MOVEHIST[MI].HMOVETO];
case P of
	EMPTY:			Piece:= NOPIECE;
	WHITEMAN_SCORE:	Piece:= WHITE_MAN;
	WHITEKING_SCORE:Piece:= WHITE_KING;
	BLACKMAN_SCORE:	Piece:= BLACK_MAN;
	BLACKING_SCORE:	Piece:= BLACK_KING;
	end;
PPiece:= Piece;
if	(MOVEHIST[MI].HPREVPIECE <> EMPTY) then
	begin
	PP:= MOVEHIST[MI].HPREVPIECE;
	case PP of
		EMPTY:			PPiece:= NOPIECE;
		WHITEMAN_SCORE:	PPiece:= WHITE_MAN;
		WHITEKING_SCORE:PPiece:= WHITE_KING;
		BLACKMAN_SCORE:	PPiece:= BLACK_MAN;
		BLACKING_SCORE:	PPiece:= BLACK_KING;
		end;
	end;

repeat
	Dec(MI);
until	(MOVEHIST[MI].HSIDE <> C)
or		(MI < 1);
Inc(MI);

repeat
	S:= MOVEHIST[MI].HMOVEFROM;
	draw_square_and_piece_SQNUM(Form1.PaintBox1, PPiece, S, HILITED);

	sleep(COMPUTER_MOVE_PAUSE);

	S:= MOVEHIST[MI].HMOVETO;
	draw_square_and_piece_SQNUM(Form1.PaintBox1, PPiece, S, HILITED);

	S:= MOVEHIST[MI].HMOVEFROM;

	if	(OPPONENT_SIDE = BLACK) then
		DrawSquare1(
			Form1.PaintBox1,
			BOARD_NUM_TO_XY_TAB_BLACK_AT_BOTTOM[S].X,
			BOARD_NUM_TO_XY_TAB_BLACK_AT_BOTTOM[S].Y,
			NOHILITE,
			S
			)
	else
		DrawSquare1(
			Form1.PaintBox1,
			BOARD_NUM_TO_XY_TAB_WHITE_AT_BOTTOM[S].X,
			BOARD_NUM_TO_XY_TAB_WHITE_AT_BOTTOM[S].Y,
			NOHILITE,
			S
			);

	sleep(COMPUTER_MOVE_PAUSE);

	S:= MOVEHIST[MI].HMOVETO;

	if	(OPPONENT_SIDE = BLACK) then
		DrawSquare1(
			Form1.PaintBox1,
			BOARD_NUM_TO_XY_TAB_BLACK_AT_BOTTOM[S].X,
			BOARD_NUM_TO_XY_TAB_BLACK_AT_BOTTOM[S].Y,
			NOHILITE,
			S
			)
	else
		DrawSquare1(
			Form1.PaintBox1,
			BOARD_NUM_TO_XY_TAB_WHITE_AT_BOTTOM[S].X,
			BOARD_NUM_TO_XY_TAB_WHITE_AT_BOTTOM[S].Y,
			NOHILITE,
			S
			);

	if	(MI = MOVEINDEX) then
		begin
		if	(OPPONENT_SIDE = BLACK) then
			DrawPiece1(
				PaintBox1,
				BOARD_NUM_TO_XY_TAB_BLACK_AT_BOTTOM[S].X,
				BOARD_NUM_TO_XY_TAB_BLACK_AT_BOTTOM[S].Y,
				Piece )
		else
			DrawPiece1(
				PaintBox1,
				BOARD_NUM_TO_XY_TAB_WHITE_AT_BOTTOM[S].X,
				BOARD_NUM_TO_XY_TAB_WHITE_AT_BOTTOM[S].Y,
				Piece )
		end
	else
		begin
		if	(OPPONENT_SIDE = BLACK) then
			DrawPiece1(
				PaintBox1,
				BOARD_NUM_TO_XY_TAB_BLACK_AT_BOTTOM[S].X,
				BOARD_NUM_TO_XY_TAB_BLACK_AT_BOTTOM[S].Y,
				PPiece )
		else
			DrawPiece1(
				PaintBox1,
				BOARD_NUM_TO_XY_TAB_WHITE_AT_BOTTOM[S].X,
				BOARD_NUM_TO_XY_TAB_WHITE_AT_BOTTOM[S].Y,
				PPiece )
		end;

	sleep(COMPUTER_MOVE_PAUSE);

	Inc(MI);
until (MI > MOVEINDEX);
DrawBoard(Form1.PaintBox1,BOARD1);
end;


(*----------------------------------------------*)
procedure complete_computer_move;
begin

if	(GAME_STATUS = GAME_ENDED)
and	(SIDETOMOVE = COMPUTER_SIDE)
then
	begin
	showmessage('I have lost!');
	exit;
	end;

display_computer_move(Form1.PaintBox1);
if DISPLAY_MESS then
	begin
	showmessage(MESS_TEXT);
	DISPLAY_MESS:= FALSE;
	MESS_TEXT:= '';
	ENGINE_ERROR_STATE:= FALSE;
	end;
end;


(*----------------------------------------------*)
procedure Human_Move_Selected(Form1:TForm1);
var
S		:integer;
Piece	:T_PIECE;

begin
if	(OPPONENT_SIDE = BLACK) then
	S:= BOARD_XY_TO_NUM_TAB_BLACK_AT_BOTTOM[cursor_X,cursor_Y]
else
	S:= BOARD_XY_TO_NUM_TAB_WHITE_AT_BOTTOM[cursor_X,cursor_Y];

if	(S > 0) then
	begin
	if	(	(   (   (BOARD1[S] = BLACKMAN_SCORE)
				OR	(BOARD1[S] = BLACKING_SCORE)
				)
			AND (OPPONENT_SIDE = BLACK)
			)
		OR  (   (   (BOARD1[S] = WHITEMAN_SCORE)
				OR  (BOARD1[S] = WHITEKING_SCORE)
				)
			AND (OPPONENT_SIDE = WHITE)
			)
		)
	THEN	// clicked on own piece
		begin
		if	(HUMAN_MOVEFROM > 0) then
			begin
			case BOARD1[HUMAN_MOVEFROM] of
				EMPTY:			Piece:= NOPIECE;
				WHITEMAN_SCORE:	Piece:= WHITE_MAN;
				WHITEKING_SCORE:Piece:= WHITE_KING;
				BLACKMAN_SCORE:	Piece:= BLACK_MAN;
				BLACKING_SCORE:	Piece:= BLACK_KING;
				end;
			DrawSquare1(Form1.PaintBox1, cursor_from_X, cursor_from_Y, NOHILITE, HUMAN_MOVEFROM);
			DrawPiece1(Form1.PaintBox1, cursor_from_X, cursor_from_Y, Piece);
			if	(S = HUMAN_MOVEFROM) then
				begin
				HUMAN_MOVEFROM:= 0;
				From_Piece:= NoPiece;
				unset_cursor_from_to;
				exit;
				end;
			end;
		HUMAN_MOVEFROM:= S;
		cursor_from_X:= cursor_X;
		cursor_from_Y:= cursor_Y;
		case BOARD1[HUMAN_MOVEFROM] of
			EMPTY:			Piece:= NOPIECE;
			WHITEMAN_SCORE:	Piece:= WHITE_MAN;
			WHITEKING_SCORE:Piece:= WHITE_KING;
			BLACKMAN_SCORE:	Piece:= BLACK_MAN;
			BLACKING_SCORE:	Piece:= BLACK_KING;
			end;
		DrawSquare1(Form1.PaintBox1, cursor_from_X, cursor_from_Y, SELECTED, HUMAN_MOVEFROM);
		DrawPiece1(Form1.PaintBox1, cursor_from_X, cursor_from_Y, Piece);
		From_Piece:= Piece;
		exit;
		end
	else		// clicked on empty square
		if	(	(S <> HUMAN_MOVEFROM)
			and	(HUMAN_MOVEFROM > 0)
			AND	(BOARD1[S] = EMPTY)
			)
		THEN
			BEGIN
			cursor_to_X:= cursor_X;
			cursor_to_Y:= cursor_Y;
			HUMAN_MOVETO:= S;
			DrawSquare1(Form1.PaintBox1, cursor_from_X, cursor_from_Y, NOHILITE, HUMAN_MOVEFROM);
			DrawSquare1(Form1.PaintBox1, cursor_to_X, cursor_to_Y, SELECTED, HUMAN_MOVETO);
			DrawPiece1(Form1.PaintBox1, cursor_to_X, cursor_to_Y, From_Piece);
			sleep(COMPUTER_MOVE_PAUSE);
			DrawSquare1(Form1.PaintBox1, cursor_from_X, cursor_from_Y, NOHILITE, HUMAN_MOVEFROM);
			DrawSquare1(Form1.PaintBox1, cursor_to_X, cursor_to_Y, NOHILITE, HUMAN_MOVETO);
			DrawPiece1(Form1.PaintBox1, cursor_to_X, cursor_to_Y, From_Piece);
			HUMAN_MOVE(HUMAN_MOVEFROM, HUMAN_MOVETO);
			if	(MOVE_STATUS = INVALIDMOVE)
			or	(MOVE_STATUS = MUSTCAPTURE)
			then
				begin
				if (MOVE_STATUS = MUSTCAPTURE) then
					showmessage('You must capture!')
				else
					showmessage('Invalid move!');
				DrawSquare1(Form1.PaintBox1, cursor_to_X, cursor_to_Y, REDLITED, HUMAN_MOVETO);
				sleep(COMPUTER_MOVE_PAUSE);
				DrawSquare1(Form1.PaintBox1, cursor_from_X, cursor_from_Y, SELECTED, HUMAN_MOVEFROM);
				DrawPiece1(Form1.PaintBox1, cursor_from_X, cursor_from_Y, From_Piece);
				sleep(COMPUTER_MOVE_PAUSE);
				DrawSquare1(Form1.PaintBox1, cursor_to_X, cursor_to_Y, NOHILITE, HUMAN_MOVETO);
				cursor_X:= cursor_from_X;
				cursor_Y:= cursor_from_Y;
				cursor_to_X:= -1; cursor_to_Y:= -1;
				HUMAN_MOVETO:= 0;
				end
			else if (MOVE_STATUS = ANOTHERMOVE) then
				begin
				cursor_X:= -1; cursor_Y:= -1;
				DrawBoard(Form1.PaintBox1,BOARD1);
				end
			else if (MOVE_STATUS = HUMANMOVED) then
				start_computer_move('Human_Move_Selected')
			else
				showmessage('Internal program error!');
			exit;
			end;
	end;
end;


(*----------------------------------------------*)
procedure Process_Settings;
label	AGAIN;
begin
AGAIN:
Settings_Form.ShowModal;

if DISPLAY_MESS then
	begin
	showmessage(MESS_TEXT);
	DISPLAY_MESS:= FALSE;
	end;

if	(Settings_Form.Depth_Control.Value = 0)
and	(Settings_Form.Seconds_Control.Value = 0) then
	begin
	showmessage('Search must be greater than zero!');
	goto AGAIN;
	end;

if	(MOVEHIST[0].HSIDE <> OPPOSITE_SIDE(SIDETOMOVE)) then
	MOVEHIST[0].HSIDE:= OPPOSITE_SIDE(SIDETOMOVE);

if	(EDIT_STATUS = EDITING_BOARD)
or	(EDIT_STATUS = VIEW_DB)
then exit;

if	(GAME_STATUS = AUTOPLAY_IN_PROGRESS) then
	begin
    ENGINE_STATE:= ENGINE_AUTOPLAYING;
    if	(THREAD_COUNT <> 0) then
	    begin
	    showmessage('Process_Settings(): THREAD_COUNT > 0');
	    end
    else
	    begin
	    THRID:= BeginThread(@AUTOPLAY,pointer(@ENGINE_STATE));
        Form1.Timer1.interval:= TIMER_DURATION;
        Form1.Timer1.enabled:= TRUE;
	    end
	end;

if	(GAME_STATUS = GAME_IN_PROGRESS) then
	continue_game('Process_Settings');
end;


(*----------------------------------------------*)
procedure TForm1.PaintBox1MouseUp(Sender:TObject;Button:TMouseButton;Shift:TShiftState;X,Y:Integer);
var
mp				:TPoint;
new_X, new_Y, S	:integer;

begin
if	(ENGINE_STATE = ENGINE_NOT_RUNNING) then
	begin
	if	(EDIT_STATUS = EDITING_BOARD) then
		begin
		mp := Mouse.CursorPos;
		mp := Form1.PaintBox1.ScreenToClient(Mouse.CursorPos);
		if (mp.X < 0) then mp.X:= 0;
		if (mp.Y < 0) then mp.Y:= 0;
		new_X:= 7; new_Y:= 7;
		while	(mp.X < Board_Pixel_XY_Table[new_X,new_Y].left_X) do Dec(new_X);
		while	(mp.Y < Board_Pixel_XY_Table[new_X,new_Y].top_Y) do Dec(new_Y);
		cursor_Y:= new_Y;
		cursor_X:= new_X;
		Human_Edit_Selected(Self);
		end
	else
	if	(GAME_STATUS = GAME_IN_PROGRESS)
	then
		begin
		mp := Mouse.CursorPos;
		mp := Form1.PaintBox1.ScreenToClient(Mouse.CursorPos);
		if (mp.X < 0) then mp.X:= 0;
		if (mp.Y < 0) then mp.Y:= 0;
		new_X:= 7; new_Y:= 7;
		while	(mp.X < Board_Pixel_XY_Table[new_X,new_Y].left_X) do Dec(new_X);
		while	(mp.Y < Board_Pixel_XY_Table[new_X,new_Y].top_Y) do Dec(new_Y);
		cursor_Y:= new_Y;
		cursor_X:= new_X;
		Human_Move_Selected(Self);
		end
	else
		Process_Settings;
	end;
end;


(*----------------------------------------------*)
procedure TForm1.FormKeyPress(Sender: TObject; var Key: char);
var
C,
White_Val,
Black_val	:integer;
S			:string;
Piece	:T_PIECE;

begin
if	(ord(Key) = 27) then
	begin
	if	(ENGINE_STATE = ENGINE_RUNNING)
	or	(ENGINE_STATE = ENGINE_AUTOPLAYING)
	then
		ENGINE_STATE:= ENGINE_QUIT
	else
		Process_Settings;
	end
else
	if	(Key = 'V')
	or	(Key = 'v')
	then
		begin
		if not DBLOADED then
			showmessage('DB not loaded')
		else
			begin
			if	(EDIT_STATUS = VIEW_DB) then
				begin
				White_Val:= lookpos(BOARD3, WHITE);
				Black_Val:= lookpos(BOARD3, BLACK);
				end
			else
				begin
				White_Val:= NOVALUE;
				Black_Val:= NOVALUE;
				if (SIDETOMOVE = BLACK) then
					Black_Val:= lookpos(BOARD1, SIDETOMOVE)
				else
					White_Val:= lookpos(BOARD1, SIDETOMOVE);
				end;
			S:= 'Score';
			if	(Black_Val <> NOVALUE) then
				S:= S+' Black = '+inttostr(Black_Val)
			else if	(White_Val <> NOVALUE) then
				S:= S+' White = '+inttostr(White_Val)
			else if	(Black_Val = NOVALUE)
				and	(White_Val = NOVALUE)
				then
					S:= 'Position not in DB';
			showmessage(S);
			end
		end
	else
		if	(Key = 'C')
		or	(Key = 'c')
		then
			begin
			if not DBLOADED then
				showmessage('DB not loaded')
			else
				if	(EDIT_STATUS = VIEW_DB) then
					begin
					S:= 'Position count = '+inttostr(DB_COUNT);
					showmessage(S);
					end;
			end
		else
			if	(Key = 'F')
			or	(Key = 'f')
			then
				begin
				if not DBLOADED then
					showmessage('DB not loaded')
				else
					if	(EDIT_STATUS = VIEW_DB) then
						begin
						C:= FIX_DB;
						S:= 'Positions fixed = '+inttostr(C);
						showmessage(S);
						end;
				end
			else if	(EDIT_STATUS = EDITING_BOARD) then
				begin
				Process_Edit_Square(self,key);
				end
;
end;


(*----------------------------------------------*)
procedure TForm1.FormKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
begin
if	(	(Key = VK_LEFT)
	or	(Key = VK_RIGHT)
	)
then
	begin
	if	(EDIT_STATUS = NOT_EDITING)
	and	(ENGINE_STATE = ENGINE_NOT_RUNNING)
	then
		begin
		if	(Shift = [ssCtrl])
		or	(Shift = [ssAlt]) then
	    	begin
			if	(Shift = [ssCtrl]) then
				case Key of
					VK_LEFT:
						begin
						if (MOVEINDEX > 1) then BACKMOVE(2);
						end;
					VK_RIGHT:	FWDMOVE(2);
					end
			else if	(Shift = [ssAlt]) then
				case Key of
					VK_LEFT:	BACKMOVE(0);
					VK_RIGHT:	FWDMOVE(0);
					end;
			DrawBoard(Form1.PaintBox1,BOARD1);
			GAME_STATUS:= GAME_IN_PROGRESS;
			if	(SIDETOMOVE = OPPONENT_SIDE) then
				begin
				MOVE_STATUS:= OPPONENT_TO_MOVE;
				HUMAN_CAPTURES:= FALSE;
				HUMAN_CAPTMAN:=EMPTY;
				LISTMOVES
					(
					OPPONENT_SIDE,
					HUMAN_CAPTMAN,
					HUMAN_MOVES,
					HUMAN_CAPTURES,
					1,
					HUMAN_MTABEND,
					HUMAN_MOBILITY
					);
				end
			else
				begin
				MOVE_STATUS:= COMPUTER_TO_MOVE;
				start_computer_move('TForm1.FormKeyDown');
				end;
			end;
		end;
	if	(EDIT_STATUS = VIEW_DB)
	and	(ENGINE_STATE = ENGINE_NOT_RUNNING)
	then
    	begin
		if	(Shift = [ssAlt]) then
			case Key of
				VK_LEFT:
					begin
					LOOKDB_INDEX:= -1;
					EMPTYBOARD(BOARD3);
					end;
				VK_RIGHT:
					begin
					LOOKDB_INDEX:= -1;
					EMPTYBOARD(BOARD3);
					end;
				end
		else
			begin
			case Key of
				VK_LEFT:	PREV_DB;
				VK_RIGHT:	NEXT_DB;
				end;
			if DISPLAY_MESS then
				begin
				showmessage(MESS_TEXT);
				DISPLAY_MESS:= FALSE;
				end;
			end;
		DrawBoard(Form1.PaintBox1,BOARD3);
		end;
	end;
end;


(*----------------------------------------------*)
procedure TForm1.Timer1Timer(Sender: TObject);
begin
if	(Processing_Timer_Message) then exit;
Processing_Timer_Message:= TRUE;
Form1.Timer1.enabled:= FALSE;

if	(GAME_STATUS = AUTOPLAY_IN_PROGRESS) then
	begin
	// if not ENGINE_DEBUG_MODE then
		DrawBoard(Form1.PaintBox1,BOARD2);
    if	(ENGINE_STATE = ENGINE_QUIT)
    or	(ENGINE_STATE = AUTOPLAY_ENDED)
    then
	    begin
	    CloseThread(THRID);
	    Settings_Form.AutoPlay.state:= cbUnchecked;
	    GAME_STATUS:= GAME_IN_PROGRESS;
		if	(ENGINE_STATE = AUTOPLAY_ENDED) then
	    	showmessage('Autoplay has finished')
		else
			showmessage('Autoplay interrupted!');
		ENGINE_STATE:= ENGINE_NOT_RUNNING;
		if	(SIDETOMOVE = COMPUTER_SIDE) then
			begin SWAPSIDES; list_human_moves; end;
		DrawBoard(Form1.PaintBox1,BOARD1);
		Processing_Timer_Message:=FALSE;
		exit;
	    end;
	end
else
	if	(ENGINE_STATE = ENGINE_FINISHED)
	or	(ENGINE_STATE = ENGINE_QUIT)
	then
	    begin
	    CloseThread(THRID);
	    if	(ENGINE_STATE = ENGINE_QUIT) then
		    showmessage('Computer interrupted!');
		ENGINE_STATE:= ENGINE_NOT_RUNNING;
	    complete_computer_move;
		if	(GAME_STATUS = GAME_IN_PROGRESS) then
			continue_game('Timer1Timer');
		Processing_Timer_Message:=FALSE;
		exit;
	    end;

Processing_Timer_Message:=FALSE;
Form1.Timer1.enabled:= TRUE;
end;


(*----------------------------------------------*)
procedure TForm1.FormPaint(Sender: TObject);
begin
Canvas.Pen.Color := clSilver;
Canvas.Brush.Color:= clSilver;
Canvas.Rectangle(0, 0, Form1.Width, Form1.Height);
end;


(*----------------------------------------------*)
procedure TForm1.FormClose(Sender: TObject {;var CloseAction: TCloseAction});
begin
write_logfile;
end;


(*----------------------------------------------*)
begin
Processing_Timer_Message:=FALSE;
LOGI:= 0;
load_piece_images;
LITEGRAY:= TColor($898989);
LITEBLACK:= TColor($484848);
DARKYELLOW:= TColor($00C0C0);
LITEGREEN:= TColor($00C000);
DARKRED:= TColor($0000A0);
DARKBLUE:= TColor($B0B000);
EMPTYBOARD(BOARD1);
NEWGAME;
cursor_X:= -1; cursor_Y:= -1;
end.

